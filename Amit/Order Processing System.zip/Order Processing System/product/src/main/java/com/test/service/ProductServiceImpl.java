package com.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.entity.Product;
import com.test.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productrepo;

	@Override
	public Product addProduct(Product product) {
		return productrepo.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		return (List<Product>) productrepo.findAll();
	}

}
