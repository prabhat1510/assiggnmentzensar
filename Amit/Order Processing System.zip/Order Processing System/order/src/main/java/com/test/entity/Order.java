package com.test.entity;

import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import javax.persistence.Entity;

@Entity
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int order_id;
	private String quantity;
	private double order_amount;

	@JoinColumn(name = "prod_id", nullable = false, unique = true)
	private Product product;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "cust_id", nullable = false, unique = true)
	private Customer customer;

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public double getOrder_amount() {
		return order_amount;
	}

	public void setOrder_amount(double order_amount) {
		this.order_amount = order_amount;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Order [getOrder_id()=" + getOrder_id() + ", getQuantity()=" + getQuantity() + ", getOrder_amount()="
				+ getOrder_amount() + ", getProduct()=" + getProduct() + ", getCustomer()=" + getCustomer() + "]";
	}

}
