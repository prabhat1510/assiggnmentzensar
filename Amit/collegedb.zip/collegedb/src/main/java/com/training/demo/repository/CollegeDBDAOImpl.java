package com.training.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.training.demo.entities.College;
import com.training.demo.entities.Student;

@Repository
public class CollegeDBDAOImpl implements CollegeDBDAO {

	@Override
	public College getCollege(Integer collegeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addCollege(College college) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getStudent(Integer studentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addStudent(Student student) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> getStudentById(Integer collegeId) {
		// TODO Auto-generated method stub
		return null;
	}

}
