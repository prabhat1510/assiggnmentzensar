package com.training.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.training.user.entity.User;
import com.training.user.service.UserService;

// URL - http://localhost:4431/
@RestController
public class UserController {

	@Autowired
	UserService userservice;

	// Create
	@PostMapping("/adduser")
	public User addUser(@RequestBody User user) {
		return userservice.addUSer(user);
	}

	// Retrieve
	@GetMapping("/getuser/{userid}")
	public User getUser(@PathVariable Integer userid) {
		return userservice.getUserById(userid);
	}

	@PutMapping("/updateuser")
	public String updateUser(@RequestBody User user) {
		return userservice.updateUser(user);
	}

	// Delete
	@DeleteMapping("/deleteuser/{userid}")
	public String deleteUser(@PathVariable Integer userid) {
		return userservice.deleteUser(userid);
	}

	// Receiving data from client
	@RequestMapping(value = "/allusers", method = RequestMethod.GET, produces = { MediaType.APPLICATION_XML_VALUE })
	public List<User> getUsers() {
		return userservice.getAllUsers();
	}

}
