package com.training.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserappApplicationTests {

	@Test
	void contextLoads() {
	}

}
