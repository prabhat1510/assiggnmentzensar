package com.training.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.training.demo.entities.Student;

@Repository
public class StudentDAOImpl implements StudentDAO {

	@Override
	public List<Student> getAllstud() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getStudentById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addStudent(Student student) {
		// TODO Auto-generated method stub
		return null;
	}

}