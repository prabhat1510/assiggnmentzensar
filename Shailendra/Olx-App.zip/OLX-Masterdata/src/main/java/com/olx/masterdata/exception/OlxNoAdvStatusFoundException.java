package com.olx.masterdata.exception;

public class OlxNoAdvStatusFoundException extends Exception {

}
