package com.java.college.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer studentId;
	private String studentName;
	//i can use here many-to-many but i have question constraints so i choose many-to-one
	//focus on foregin key 
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "CollegeId", referencedColumnName = "collegeId")
	private College college;

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public College getColleges() {
		return college;
	}

	public void setColleges(College college) {
		this.college = college;
	}

}