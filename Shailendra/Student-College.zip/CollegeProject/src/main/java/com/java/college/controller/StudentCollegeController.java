package com.java.college.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.java.college.entity.College;
import com.java.college.entity.Student;
import com.java.college.service.StudentService;

@RestController
public class StudentCollegeController {

	@Autowired
	private StudentService studentService;

	/*
	 * @GetMapping("/student/{ids}") public List<Student>
	 * getAllStudentById(@PathVariable Iterable<Integer> ids) {
	 * 
	 * return studentService.Students(ids);
	 * 
	 * }
	 */
	@GetMapping("/students")
	public List<Student> getAllStudent() {
		return studentService.getAllStudent();
	}

	@PostMapping("/addStudent")
	public Integer addStudent(@RequestBody Student student) {

		
		studentService.saveStudent(student);
		return student.getStudentId();

	}

	@GetMapping("/colleges")
	public List<College> getAllCollege(College college) {
		return studentService.getCollege(college);

	}

	@PostMapping("/addcollage")
	public Integer addCollege(College college) {

		return studentService.addCollege(college);

	}

	@PostMapping("/getstudentbycollegeid/{id}")
	public Optional<Student> getStudentByCollegeId(@PathVariable("id") Integer collegeId) {

		Optional<Student> oop = studentService.getStudentByCollegeId(collegeId);
		oop.stream().forEach(System.out::println);
		return oop;

	}

	@GetMapping("/getlistbyCollegeid/{id}")
	public List<Student> getStudentAndCollege(@PathVariable Integer id) {
		return studentService.getStudent(id);
	}
	

}
