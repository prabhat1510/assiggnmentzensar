package com.java.college.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.java.college.entity.College;
import com.java.college.entity.Student;

@Repository
public interface CollageRepository extends JpaRepository<College, Integer> {
	/*
	 * //@Query(value =
	 * "SELECT * FROM student join college on college.college_id= student.college_id where student.college_id =?;"
	 * , nativeQuery = true) public College findCollegebyId(Integer Id);
	 */

}
