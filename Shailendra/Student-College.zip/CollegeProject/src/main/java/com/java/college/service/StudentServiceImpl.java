package com.java.college.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.college.entity.College;
import com.java.college.entity.Student;
import com.java.college.repository.CollageRepository;
import com.java.college.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private CollageRepository collageRepository;

	@Override
	public Integer saveStudent(Student student) {

		Student saveStudent = studentRepository.save(student);

		return student.getStudentId();
	}

	@Override
	public List<Student> getStudents(Iterable<Integer> ids) {

		return studentRepository.findAllById(ids);

	}

	@Override
	public Integer addCollege(College college) {

		College college2 = collageRepository.save(college);
		return college.getCollegeId();
	}

	@Override
	public List<College> getCollege(College college) {
		return collageRepository.findAll();
	}

	@Override
	public Optional<Student> getStudentByCollegeId(Integer collegeId) {
		return studentRepository.findById(collegeId);
	}

	@Override
	public List<Student> getStudent(Integer id) {

		return studentRepository.getStudent(id);
	}

	@Override
	public Optional<College> getCollegeId(Integer Id) {

		Optional<College> option = collageRepository.findById(Id);

		return option;
	}

	@Override
	public List<Student> getAllStudent() {
		return studentRepository.findAll();
	}

	@Override
	public List<Student> getData(College college) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> getAllStudentByid() {
		// TODO Auto-generated method stub
		return null;
	}

}
