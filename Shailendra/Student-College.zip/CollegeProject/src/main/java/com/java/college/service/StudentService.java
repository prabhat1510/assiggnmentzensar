package com.java.college.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;

import com.java.college.entity.College;
import com.java.college.entity.Student;

public interface StudentService {
	Integer saveStudent(Student student);

	@Query(value = "select * from student where college_id =?;", nativeQuery = true)
	List<Student> getStudents(Iterable<Integer> ids);

	Integer addCollege(College college);

	public List<Student> getAllStudent();

	List<College> getCollege(College college);

	@Query(value = "select * from student where college_id =?;", nativeQuery = true)
	Optional<Student> getStudentByCollegeId(Integer collegeId);

	List<Student> getData(College college);

	@Query(value = "SELECT * FROM student join college on college.college_id= student.college_id where student.college_id =?;", nativeQuery = true)
	public Optional<College> getCollegeId(Integer CollegeId);

	List<Student> getStudent(Integer id);
	
	List<Student> getAllStudentByid();

}
