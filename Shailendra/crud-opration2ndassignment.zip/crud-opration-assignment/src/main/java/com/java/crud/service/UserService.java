package com.java.crud.service;

import java.util.List;

import com.java.crud.entity.User;
import com.java.crud.exception.NoUserFoundException;

public interface UserService {
	User addUser(User user) throws NoUserFoundException;

	String updateUser(User user) throws NoUserFoundException;

	String deleteUser(Integer Id) throws NoUserFoundException;

	List<User> getAllUser() throws NoUserFoundException;

	User getUserById(Integer Id) throws NoUserFoundException;

	User getUserByName(String userName) throws NoUserFoundException;

}
