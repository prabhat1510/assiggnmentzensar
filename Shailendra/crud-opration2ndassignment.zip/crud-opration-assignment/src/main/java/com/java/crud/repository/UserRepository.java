package com.java.crud.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.java.crud.entity.User;
@Repository
public interface UserRepository extends CrudRepository<User, Integer> {
	 User findUserByName(String name);

}
