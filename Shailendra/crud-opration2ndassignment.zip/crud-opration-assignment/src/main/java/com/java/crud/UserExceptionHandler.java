package com.java.crud;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.java.crud.exception.NoUserFoundException;

@RestControllerAdvice
public class UserExceptionHandler {
	@ExceptionHandler(NoUserFoundException.class)
	public ResponseEntity<Object> handleNoUserFoundExceptionn() {
		return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
	}

}
