package com.java.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.crud.entity.User;
import com.java.crud.exception.NoUserFoundException;
import com.java.crud.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;

	@Override
	public User addUser(User user) throws NoUserFoundException {

		User savedUser = userRepository.save(user);
		if (savedUser != null) {
			return savedUser;

		}

		throw new NoUserFoundException("User not save");
	}

	@Override
	public String updateUser(User user) throws NoUserFoundException {
		Optional<User> id = userRepository.findById(user.getId());
		User userWithData = userRepository.save(user);
		if (userWithData != null) {
			return "User updated successfully";
		}

		throw new NoUserFoundException("User  not updated successfully");

	}

	@Override
	public String deleteUser(Integer userId) throws NoUserFoundException {

		try {
			userRepository.deleteById(userId);
			return "user with id ---" + userId + "  deleted successfully";

		} catch (Exception e) {

			throw new NoUserFoundException("Delete Can be undone or " + userId + " not existed in database");
		}
	}

	@Override
	public List<User> getAllUser() throws NoUserFoundException {
		// TODO Auto-generated method stub
		return (List<User>) userRepository.findAll();
	}

	@Override
	public User getUserById(Integer userId) throws NoUserFoundException {

		Optional<User> user = userRepository.findById(userId);
		if (user.isPresent()) {
			return user.get();
		} else {
			throw new NoUserFoundException("User Not found " + userId + "or Not Exist in database");

		}

	}

	@Override
	public User getUserByName(String userName) throws NoUserFoundException {
		try {
			return userRepository.findUserByName(userName);
		} catch (Exception e) {
			throw new NoUserFoundException("User with Name" + userName + " Not found or Not Exist in database");

		}

	}

}
