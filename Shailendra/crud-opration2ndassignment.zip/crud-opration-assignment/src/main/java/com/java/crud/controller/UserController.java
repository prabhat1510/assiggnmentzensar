package com.java.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.crud.entity.User;
import com.java.crud.exception.NoUserFoundException;
import com.java.crud.service.UserService;

@RestController
@RequestMapping("/api/user")
public class UserController {
	@Autowired
	private UserService userService;

	@PostMapping("/adduser")
	public User addUser(User user) throws NoUserFoundException {
		return userService.addUser(user);

	}

	@PutMapping("/updateuser")
	String updateUser(User user) throws NoUserFoundException {
		return userService.updateUser(user);
	}

	@DeleteMapping("delete/{id}")
	String deleteUser(@PathVariable("id") Integer Id) throws NoUserFoundException {
		return userService.deleteUser(Id);

	}

	@GetMapping("/users")
	List<User> getAllUser() throws NoUserFoundException {
		return userService.getAllUser();
	}

	@GetMapping("/getUserbyid/{id}")
	User getUserById(@PathVariable("id") Integer userId) throws NoUserFoundException {
		return userService.getUserById(userId);
	}

	@GetMapping("userbyname/{name}")
	User getUserByName(@PathVariable("name") String userName) throws NoUserFoundException {
		return userService.getUserByName(userName);
	}

}
